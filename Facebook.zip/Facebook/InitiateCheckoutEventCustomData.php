<?php

namespace Leiturinha\Object\Facebook;

use Leiturinha\Object\Facebook\EventCustomData;

/**
 * Facebook Initiate Checkout Event - Custom Params
 */

class InitiateCheckoutEventCustomData extends EventCustomData
{

}
