<?php

namespace Leiturinha\Object\Facebook;

use Leiturinha\Object\Facebook\EventCustomData;

class AddtoCartEventCustomData extends EventCustomData
{

}
