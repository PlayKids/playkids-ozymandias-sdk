<?php

namespace Leiturinha\Object\Facebook;


class PageViewEventCustomData
{

}
