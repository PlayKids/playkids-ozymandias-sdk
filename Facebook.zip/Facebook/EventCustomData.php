<?php

namespace Leiturinha\Object\Facebook;

abstract class EventCustomData {
    public function validate(){}
}
