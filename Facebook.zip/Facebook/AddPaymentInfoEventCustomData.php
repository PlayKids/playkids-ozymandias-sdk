<?php

namespace Leiturinha\Object\Facebook;

class AddPaymentInfoEventCustomData extends EventCustomData
{


}
